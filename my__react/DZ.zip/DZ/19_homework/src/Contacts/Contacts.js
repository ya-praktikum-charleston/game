import React from 'react';

import './Contacts.css';

class Contacts extends React.Component{

    render() {
        return (
            <div>Контакты</div>
        );
    };
}

export default Contacts;
