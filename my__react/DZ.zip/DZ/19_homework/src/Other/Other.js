import React from 'react';

import './Other.css';


class Other extends React.Component{

    render(){

        return (
            <div className="other">
                <h1>страница 404</h1>
            </div>
        );

    };
}



export default Other;


