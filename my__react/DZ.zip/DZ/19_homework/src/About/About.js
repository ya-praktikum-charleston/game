import React from 'react';

import './About.css';

class About extends React.Component{

    render() {
        return (
            <div>Пункты обмена</div>
        );
    };
}

export default About;
