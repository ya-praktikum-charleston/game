import React from 'react';

import './App.css';


class App extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            squares: Array(9).fill(null),
            count: 0,
            O: 0,
            X: 0,
            showGame: false,
            playGame: false,
            XO: []
        };
        this.winnerLine = [
            [0, 1, 2],
            [3, 4, 5],
            [6, 7, 8],
            [0, 3, 6],
            [1, 4, 7],
            [2, 5, 8],
            [0, 4, 8],
            [2, 4, 6],
        ]
    };

    clickHandler = (e) => {

        if( this.state.playGame ){
            let data = e.target.getAttribute('data');
            let currentSquare = this.state.squares;

            if( currentSquare[data] === null ){
                let step = (this.state.count % 2) ? this.state.XO[1] : this.state.XO[0];
                currentSquare[data] = step;
                this.setState({
                    squares: currentSquare,
                    count: ++this.state.count,
                });
                this.isWinner(step);
            }
        }

    };

    isWinner = (s) => {

        let flagWin = true;

        for( let i = 0; i < 8; i++ ){
            let line = this.winnerLine[i];
            if(
                this.state.squares[line[0]] === s
                &&
                this.state.squares[line[1]] === s
                &&
                this.state.squares[line[2]] === s
            ){
                alert(s + ' - WIN');
                flagWin = false;
                this.setState({
                    playGame: false,
                    [s]: ++this.state[s]
                });
            }
        }

        if( this.state.count > 8 && flagWin){
            alert('Ничья');
            this.setState({ playGame: false });
        }

    };

    showGame = () => {

        let flag = window.confirm("Играть 'O' - Да. Играть 'Х' - Нет.");
        if(flag){
            this.setState({ XO: ['O','X'] });
        }
        else{
            this.setState({ XO: ['X','O'] });
        }
        this.setState({
            squares: Array(9).fill(null),
            count: 0,
            showGame: true,
            playGame: true,
        })
    };

    render(){

        let ticTacToe = '';
        if (this.state.showGame) {

            ticTacToe =
                <div className="cross-zero">
                    <div className="tic-tac-toe">
                        <div className="ttt-grid" onClick={this.clickHandler} data="0">{this.state.squares[0]}</div>
                        <div className="ttt-grid" onClick={this.clickHandler} data="1">{this.state.squares[1]}</div>
                        <div className="ttt-grid" onClick={this.clickHandler} data="2">{this.state.squares[2]}</div>
                        <div className="ttt-grid" onClick={this.clickHandler} data="3">{this.state.squares[3]}</div>
                        <div className="ttt-grid" onClick={this.clickHandler} data="4">{this.state.squares[4]}</div>
                        <div className="ttt-grid" onClick={this.clickHandler} data="5">{this.state.squares[5]}</div>
                        <div className="ttt-grid" onClick={this.clickHandler} data="6">{this.state.squares[6]}</div>
                        <div className="ttt-grid" onClick={this.clickHandler} data="7">{this.state.squares[7]}</div>
                        <div className="ttt-grid" onClick={this.clickHandler} data="8">{this.state.squares[8]}</div>
                    </div>
                    <ul className="score">
                        <li>Счёт:</li>
                        <li>O: {this.state.O}</li>
                        <li>X: {this.state.X}</li>
                    </ul>
                </div>


            ;
        }else{
            ticTacToe = '';
        }

        return (
            <div className="App">
                <button onClick={this.showGame}>Начать новую игру</button>

                {ticTacToe}

            </div>
        );

    };
}



export default App;


