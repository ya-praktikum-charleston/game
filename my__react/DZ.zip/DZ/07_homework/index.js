import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './app/App';
import * as serviceWorker from './serviceWorker';

let contacts = ['8 900 444 33 22', '8 800 333 99 00'];
let adress = ['Новосибирск', 'Ленина', '22'];
let titleFooter = 'Контакты';

ReactDOM.render(<App contacts={contacts} adress={adress} titleFooter={titleFooter}/>, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
