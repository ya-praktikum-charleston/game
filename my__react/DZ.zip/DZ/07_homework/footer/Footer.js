import React from 'react';
import './Footer.css';

class Footer extends React.Component{
    render(){
        let contacts = this.props.contacts;
        let adress = this.props.adress;
        let titleFooter = this.props.titleFooter;
        console.log(adress);
        return (
            <footer>
                <div className="container">
                    <h3>{titleFooter}</h3>
                    <div className="footer_main">
                        <div className="phone">
                            <div className="phone_left">
                                <p>Телефон:</p>
                            </div>
                            <div className="phone_right">
                                {Object.keys(contacts).map( elem => {
                                    return <p>{contacts[elem]}</p>
                                })}
                            </div>
                        </div>
                        <div className="adress">
                            <p>г. {adress[0]}</p>
                            <p>Адресс: ул.{adress[1]} д{adress[2]}</p>
                        </div>
                        <div></div>
                    </div>
                </div>
            </footer>
        )
    }
}

export default Footer;