import React from 'react';

import './App.css';
import Header from '../header/Header.js';
import Main from '../main/Main.js';
import Footer from '../footer/Footer.js';

class App extends React.Component{
    render(){
        let contacts = this.props.contacts;
        let adress = this.props.adress;
        let titleFooter = this.props.titleFooter;
        return (
            <div className="App">
                <div className="main_wrapper">
                    <div className="wrapper">
                        <Header />
                        <Main />
                    </div>
                    <div className="wrapper">
                        <Footer contacts={contacts} adress={adress} titleFooter={titleFooter} />
                    </div>
                </div>
            </div>
        );
    }
}

export default App;
