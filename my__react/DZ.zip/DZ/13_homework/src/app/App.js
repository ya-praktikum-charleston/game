import React from 'react';

import './App.css';


class App extends React.Component{
    constructor(props){
        super(props);
        this.state = {

        };

    };

    generatColor() {

        let min = 0;
        let max = 255;

        let a = Math.floor(Math.random() * (max - min + 1)) + min;
        let b = Math.floor(Math.random() * (max - min + 1)) + min;
        let c = Math.floor(Math.random() * (max - min + 1)) + min;

        return `rgb(${a},${b},${c})`;
    }

    generateNum(){
        let a = '';
        for(let i = 0; i <= 100; i++){
            a += i +' ';
        }
        return a;
    }

    render(){

        let arr = [1,2,3,4,5];
        let arr2 = [1,0,1,0];

        return (
            <div className="App">

                <p>Task 1</p>
                <p><i>Используя Expression выведите на страницу случайное число в диапазоне от 50 до 60 включительно. Число должно обновляться при загрузке страницы.</i></p>

                <p>{Math.floor(Math.random() * (60 - 50 + 1)) + 50}</p>

                <br/>

                <p>Task 2</p>
                <p><i>Создайте блок, через inline стили присвойте ему цвет фона. Причем цвет должен случайно меняться при загрузке страницы.</i></p>

                <div className="ts2" style={{backgroundColor:this.generatColor()}}></div>

                <br/>

                <p>Task 3</p>
                <p><i>Выведите с помощью Expression на страницу массив вида [1,2,3,4,5], каждый элемент списка должен быть выведен в отдельный параграф. Проверьте, необходимо ли добавлять ключ к параграфу? Если да - добавьте.</i></p>

                {arr.map( elem => {
                    return <p key={elem}>{elem}</p>
                })}

                <br/>

                <p>Task 4</p>
                <p><i>У вас есть массив [1,0,1,0]. Используя expression выведите на страницу данный массив, причем каждый элемент должен быть помещен в div. Если элемент равен 1, то div должен иметь класс white, если 0 - black.</i></p>

                {Object.keys(arr2).map( key => {
                    return <div key={key} className={(arr2[key] === 1) ? 'white' : 'black'}>{arr2[key]}</div>
                })}

                <br/>

                <p>Task 5</p>
                <p><i>Распечатайте цифры от 1 до 100 на странице с помощью expression.</i></p>

                <p>{this.generateNum()}</p>

            </div>
        );

    };
}



export default App;


