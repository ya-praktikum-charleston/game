import React from 'react';

import './App.css';


class App extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            text: "Hello",
            count : 0,
            inpVal: "Введи текст",
            radioVal: "1",
            selectVal: "1",
            divWidth: '',
            rangeVal: '50',
            imgToogle: true
        };
        this.showText = this.showText.bind(this);
        //this.state.divWidth = document.querySelector('.task12').textContent;
    };
    showText() {
        this.setState({ text: 'button work' });
        console.log('button work');
    };
    Count = () => {
        this.setState({ count: this.state.count + 1 });

    };
    ResetCount = () => {
        this.setState({ count: 0 });

    };
    move(){
        console.log('move');
    };
    Art(e) {
        console.log(e.target.getAttribute('data'));
    };
    inpText = (e) => {
        let val = e.target.value;
        if( val.length < 6 ){
            val = 'Теск меньше 6 символов';
        }else{
            val = e.target.value;
        }
        this.setState({ inpVal: val });
    };
    checkboxFunk = (e) => {
        if( e.target.checked ){
            console.log('checkbox checked');
        }else{
            console.log('checkbox unchecked');
        }
    };
    radioFunk = (e) => {
        this.setState({ radioVal: e.target.value });
    };
    sectionFunk = (e) => {
        this.setState({ selectVal: e.target.value });
    };
    divFunk = () => {
        let div = document.querySelector('.task12');
        div.style.width = div.offsetWidth + 3 + 'px';
    };
    divResetFunk = () =>{
        let div = document.querySelector('.task12');
        div.style.width = 200 + 'px';
    };
    rangeFunk = (e) => {
        this.setState({ rangeVal: e.target.value });
    };
    imgToogle = () => {
        let div = document.querySelector('.img_toogle');
        if(this.state.imgToogle){
            this.setState({ imgToogle: false });
            div.style.display = "none";
        }else{
            this.setState({ imgToogle: true });
            div.style.display = "block";
        }
    }
    render(){

        return (
            <div className="App">

                <p><i>===  Task 1 - 2</i></p>
                <p>{this.state.text}</p>


                <p><i>===  Task 3</i></p>
                <button onClick={this.Count}>Count</button>
                <p>{this.state.count}</p>


                <p><i>===  Task 4</i></p>
                <button onClick={this.ResetCount}>ResetCount</button>


                <p><i>===  Task 5</i></p>
                <div className="task5" onMouseMove={this.move}></div>


                <p><i>===  Task 6</i></p>
                <button data="atr1" onClick={this.Art}>atr1</button>
                <button data="atr2" onClick={this.Art}>atr2</button>


                <p><i>===  Task 7 - 8</i></p>
                <input type="text" defaultValue={this.state.inpVal} onInput={ this.inpText } />
                <p>{this.state.inpVal}</p>


                <p><i>===  Task 9</i></p>
                <input type="checkbox" onInput={ this.checkboxFunk } defaultChecked={true} />


                <p><i>===  Task 10</i></p>
                <input type="radio" name="radio" onInput={ this.radioFunk } defaultValue={'1'} defaultChecked={true} />
                <input type="radio" name="radio" onInput={ this.radioFunk } defaultValue={'2'} />
                <input type="radio" name="radio" onInput={ this.radioFunk } defaultValue={'3'} />
                <p>{this.state.radioVal}</p>


                <p><i>===  Task 11</i></p>
                <select onChange={ this.sectionFunk }>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                </select>
                <p>{this.state.selectVal}</p>


                <p><i>===  Task 12</i></p>
                <div className="task12"></div>
                <button onClick={ this.divFunk }>Добавить ширину div</button>
                <button onClick={ this.divResetFunk }>Сбросить ширину div</button>


                <p><i>===  Task 13</i></p>
                <input type="range" min="0" max="100" step="1" defaultValue={this.state.rangeVal} onChange={ this.rangeFunk } />
                <p>{this.state.rangeVal}</p>


                <p><i>===  Task 14</i></p>
                <button onClick={ this.imgToogle }>Кнопка</button>
                <br/>
                <img src="https://avatars.mds.yandex.net/get-pdb/202366/fb7cf1f2-6ce1-41d4-aa4a-8ce79bf2baf8/s1200" alt="" className="img_toogle"/>
                <br/>

            </div>
        );

    };
}



export default App;


