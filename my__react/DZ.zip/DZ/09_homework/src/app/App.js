import React from 'react';

import './App.css';


class App extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            text: "Hello",
            count : 0,
            inpVal: "Введи текст",
            radioVal: "1",
            selectVal: "1",
            divWidth: '',
            rangeVal: '50',
            imgToogle: true
        };
        this.showText = this.showText.bind(this);
        //this.state.divWidth = document.querySelector('.task12').textContent;
    };
    showText() {
        this.setState({ text: 'button work' });
        console.log('button work');
    };
    Count = () => {
        this.setState({ count: this.state.count + 1 });

    };
    ResetCount = () => {
        this.setState({ count: 0 });

    };
    move(){
        console.log('move');
    };
    Art(e) {
        console.log(e.target.getAttribute('data'));
    };
    inpText = (e) => {
        let val = e.target.value;
        if( val.length < 6 ){
            val = 'Теск меньше 6 символов';
        }else{
            val = e.target.value;
        }
        this.setState({ inpVal: val });
    };
    checkboxFunk = (e) => {
        if( e.target.checked ){
            console.log('checkbox checked');
        }else{
            console.log('checkbox unchecked');
        }
    };
    radioFunk = (e) => {
        this.setState({ radioVal: e.target.value });
    };
    sectionFunk = (e) => {
        this.setState({ selectVal: e.target.value });
    };
    divFunk = () => {
        let div = document.querySelector('.task12');
        div.style.width = div.offsetWidth + 3 + 'px';
    };
    divResetFunk = () =>{
        let div = document.querySelector('.task12');
        div.style.width = 200 + 'px';
    };
    rangeFunk = (e) => {
        this.setState({ rangeVal: e.target.value });
    };
    imgToogle = () => {
        let div = document.querySelector('.img_toogle');
        if(this.state.imgToogle){
            this.setState({ imgToogle: false });
            div.style.display = "none";
        }else{
            this.setState({ imgToogle: true });
            div.style.display = "block";
        }
    }
    render(){

        return (
            <div className="App">

                <p><i>===  Task 1 - 2</i></p>
                <p>Создайте кнопку. Повесьте на нее событие click. При клике выводите в консоль сообщение - button work.</p>
                <p>Добавьте параграф. При клике по кнопке - выводите текст button work в параграф.</p>
                <p>{this.state.text}</p>


                <p><i>===  Task 3</i></p>
                <p>Добавьте кнопку с текстом Count. Создайте state.count = 0 и выведите его на страницу в параграф. Добавьте на кнопку Count событие, которое будет вызывать метод увеличивающий state.count на единицу при каждом нажатии.</p>
                <button onClick={this.Count}>Count</button>
                <p>{this.state.count}</p>


                <p><i>===  Task 4</i></p>
                <p>Добавьте кнопку ResetCount обновляющую count в предыдущей задаче.</p>
                <button onClick={this.ResetCount}>ResetCount</button>


                <p><i>===  Task 5</i></p>
                <p>Добавьте div зеленого цвета. Повесьте на него событие mousemove и при срабатывании выводите в консоль слово move.</p>
                <div className="task5" onMouseMove={this.move}></div>


                <p><i>===  Task 6</i></p>
                <p>Добавьте 2 кнопки с надписями atr1 и atr2. Задайте им атрибуты data = atr-1 и data = atr-2 соответственно. Добавьте по клику на кнопке метод (один и тот же). Метод должен выводить содержимое атрибута data в консоль.</p>
                <button data="atr1" onClick={this.Art}>atr1</button>
                <button data="atr2" onClick={this.Art}>atr2</button>


                <p><i>===  Task 7 - 8</i></p>
                <p>Добавьте input и параграф. При вводе текста в input - выводите в параграфе вводимый текст.</p>
                <p>Усложним задачу. Если длина вводимого текста меньше 6 символов - то выводите на страницу предупреждение о том, что длина меньше 6.</p>
                <input type="text" defaultValue={this.state.inpVal} onInput={ this.inpText } />
                <p>{this.state.inpVal}</p>


                <p><i>===  Task 9</i></p>
                <p>Добавьте checkbox - при изменении его состояния выводите checkbox checked или checkbox unchecked в консоль.</p>
                <input type="checkbox" onInput={ this.checkboxFunk } defaultChecked={true} />


                <p><i>===  Task 10</i></p>
                <p>Добавьте 3 radiobutton с одним именем. При изменении состояния radiobutton выводите value выбранного на страницу.</p>
                <input type="radio" name="radio" onInput={ this.radioFunk } defaultValue={'1'} defaultChecked={true} />
                <input type="radio" name="radio" onInput={ this.radioFunk } defaultValue={'2'} />
                <input type="radio" name="radio" onInput={ this.radioFunk } defaultValue={'3'} />
                <p>{this.state.radioVal}</p>


                <p><i>===  Task 11</i></p>
                <p>Добавьте выпадающий список. При изменении состояния - выводите value выбранного на страницу.</p>
                <select onChange={ this.sectionFunk }>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                </select>
                <p>{this.state.selectVal}</p>


                <p><i>===  Task 12</i></p>
                <p>Добавьте div и кнопку. При нажатии кнопки - увеличивайте ширину div на 3 px. Добавьте кнопку Reset позволяющую сбрасывать состояние до начальной ширины.</p>
                <div className="task12"></div>
                <button onClick={ this.divFunk }>Добавить ширину div</button>
                <button onClick={ this.divResetFunk }>Сбросить ширину div</button>


                <p><i>===  Task 13</i></p>
                <p>Добавьте полнузок. При изменении ползунка выводите его value на страницу.</p>
                <input type="range" min="0" max="100" step="1" defaultValue={this.state.rangeVal} onChange={ this.rangeFunk } />
                <p>{this.state.rangeVal}</p>


                <p><i>===  Task 14</i></p>
                <p>Добавьте кнопку и изображение. При клике на кнопку скрывайте изображение, при повторном клике - показывайте.</p>
                <button onClick={ this.imgToogle }>Кнопка</button>
                <br/>
                <img src="https://avatars.mds.yandex.net/get-pdb/202366/fb7cf1f2-6ce1-41d4-aa4a-8ce79bf2baf8/s1200" alt="" className="img_toogle"/>
                <br/>

            </div>
        );

    };
}



export default App;


