import React from 'react';

import './App.css';


class App extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            text: "",
            number: "",
            range: 50,
            textarea: "",
            select: "1",
            showTable: false,
            subClick: false
        };

    };
    myInput = (e) => {
        this.setState({ [e.target.name]: e.target.value });
    };
    submitForm = (e) => {
        e.preventDefault();
        this.setState({ subClick: true });
    };
    render(){
        let arrState = this.state;
        let flagCol = 0;

        for(let key in arrState){
            if(arrState[key] === ''){
                ++flagCol;
            }
        }

        if(flagCol){
            this.state.showTable = false;
            this.state.subClick = false;
        }else{
            this.state.showTable = true;
        }

        let table = '';
        if (this.state.showTable && this.state.subClick) {

            table =
                <div className="contain">
                    <table>
                        <tbody>
                        <tr>
                            <th>Текст</th>
                            <td>{this.state.text}</td>
                        </tr>
                        <tr>
                            <th>Число</th>
                            <td>{this.state.number}</td>
                        </tr>
                        <tr>
                            <th>Диапазон</th>
                            <td>{this.state.range}</td>
                        </tr>
                        <tr>
                            <th>Textarea</th>
                            <td>{this.state.textarea}</td>
                        </tr>
                        <tr>
                            <th>Select</th>
                            <td>{this.state.select}</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            ;
        }else{
            table = '';
        }
        return (
            <div className="App">

                <form onSubmit={this.submitForm}>

                    <input type="text" name="text" onChange={this.myInput} />
                    <br/>
                    <input type="number" name="number" onChange={this.myInput} />
                    <br/>
                    <input type="range" name="range" min="0" max="100" step="1" defaultValue={ this.state.range } onChange={this.myInput} />
                    <br/>
                    <textarea name="textarea" id="" cols="30" rows="10" onChange={this.myInput}></textarea>
                    <br/>
                    <select name="select" onChange={this.myInput}>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                    </select>
                    <br/>
                    <button type="submit" disabled={!this.state.showTable}>Кнопка</button>


                    {table}


                </form>

            </div>
        );

    };
}



export default App;


