import React from 'react';
import logo from './logo.svg';
import './Mac.css';


class Mac {
    constructor( height, weight, age, sex, name, passport, eye ) {
        this.height = height;
        this.weight = weight;
        this.age = age;
        this.sex = sex;
        this.name = name;
        this.passport = passport;
        this.eye = eye;
    }
    macFunk() {
        console.log(
            this.height,
            this.weight,
            this.age,
            this.sex,
            this.name,
            this.passport,
            this.eye
        )
    }

}


/*
function Mac() {
    return (
        <div className="Mac">

            <div className="container">
                <div className="row">
                    <div className="col col-lg-12">
                        <h1>First React APP</h1>
                        <img src="https://cdn0.iconfinder.com/data/icons/flat-round-system/512/reactos-256.png" alt=""/>
                        <p>my first react app</p>
                        <button className="button-primary">Default</button>
                        <br/>
                        <br/>
                        <table cellspacing="0">
                            <tbody>
                            <tr>
                                <th>Имя</th>
                                <td>Виталий</td>
                            </tr>
                            <tr>
                                <th>Возраст</th>
                                <td>32</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    );
}
*/

export default Mac;
