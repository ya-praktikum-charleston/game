import React from 'react';

import './App.css';


class App2 extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            y1: "txt",
        };
    };

    static getDerivedStateFromProps(props, state){
        return {
            y1: String(props.z1*10)
        }
    }

    render(){

        return (
            <div>
                <p><i>Task 4</i></p>
                <p>{this.props.z1}</p>
                <br/>

                <p><i>Task 5</i></p>
                <p>{this.state.y1}</p>
            </div>



        );

    };
}



export default App2;


