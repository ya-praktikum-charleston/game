import React from 'react';
import App2 from './App2';
import './App.css';


class App extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            s1: "txt",
            s2: "txt",
            s3: 'txt',
        };
    };

    static getDerivedStateFromProps(props, state){
        return {
            s1: props.a1,
            s2: props.a2,
        }
    }

    componentDidMount(){
        this.setState({ s3: this.state.s1 * this.state.s2 })
    }

    render(){

        return (
            <div className="App">

                <p><i>Task 1</i></p>
                <p>{this.props.a1}</p>
                <p>{this.props.a2}</p>
                <br/>

                <p><i>Task 2</i></p>
                <p>{this.state.s1}</p>
                <p>{this.state.s2}</p>
                <br/>

                <p><i>Task 3</i></p>
                <p>{this.state.s3}</p>
                <br/>


                <App2 z1={this.state.s3} />


            </div>
        );

    };
}



export default App;


