
// Task 1
let man = new Man('Жора', '79', '4392 841007', 'уже всё');
console.log(man);



// Task 2
let employer = new Employer('Жора', '79', '4392 841007', 'уже всё', '1962', '70р');
console.log(employer);



// Task 4

man.render('.out-1');


// Task 5

employer.render('.out-2');



// Task 8

console.log(employer.name);



// Task 9

employer.name = '   Гриша  ';
console.log(employer.name);

employer.name = 404;
console.log(employer.name);
