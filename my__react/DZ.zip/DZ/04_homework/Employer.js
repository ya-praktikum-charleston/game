class Employer extends Man{
    constructor( name, age, passport, sex, create, salary ) {
        super(name, age, passport, sex);
        this.create = create;
        this.salary = salary;
    }
    get name(){
        return this._name;
    }
    set name(x) {
        if(typeof x === "string"){
            this._name = x.trim();
        }
    }
    /*render(div){
        let txt = '';
        txt += `<p>${this.name}</p>`;
        txt += `<p>${this.age}</p>`;
        txt += `<p>${this.passport}</p>`;
        txt += `<p>${this.sex}</p>`;
        txt += `<p>${this.create}</p>`;
        txt += `<p>${this.salary}</p>`;

        document.querySelector(div).innerHTML = txt;
    }*/
    render(div){

        super.render(div);

        let txt = '';
        txt += `<p>${this.create}</p>`;
        txt += `<p>${this.salary}</p>`;

        document.querySelector(div).innerHTML += txt;
    }
}