class Man {
    constructor( name, age, passport, sex ) {
        this._name = name;
        this.age = age;
        this.passport = passport;
        this.sex = sex;
    }
    render(div){

        let txt = '';
        txt += `<p>${this._name}</p>`;
        txt += `<p>${this.age}</p>`;
        txt += `<p>${this.passport}</p>`;
        txt += `<p>${this.sex}</p>`;

        document.querySelector(div).innerHTML = txt;

    }
}