import React from 'react';

import './App.css';

import { BrowserRouter as Router, Switch, Route} from 'react-router-dom';

import Header from '../Header/Header.js';
import Main from '../Main/Main.js';
import Footer from '../Footer/Footer.js';

import Exercises from '../Exercises/Exercises.js';
import Calc from '../Calc/Calc.js';
import Form from '../Form/Form.js';
import Other from '../Other/Other';


class App extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            nav: {
                main: {
                    component: 'Main', title: 'ГЛАВНАЯ', link: '/'
                },
                exercises: {
                    component: 'Exercises', title: 'УПРАЖНЕНИЯ', link: '/exercises'
                },
                form: {
                    component: 'Form', title: 'ФОРМА', link: '/form'
                },
                calc: {
                    component: 'Calc', title: 'КАЛЬКУЛЯТОР', link: '/calc'
                },
                '404': {
                    component: 'Other', title: '404', link: ''
                },
            }
        };

    };

    render(){

        return (
            <div className="App">

                <div className="main_wrapper">
                    <div className="wrapper">
                        <Header nav={this.state.nav}/>
                        <div className="main">
                            <div className="container">
                                <Router>
                                    <Switch>
                                        <Route exact path="/" component={() => <Main nav={this.state.nav}/>}/>
                                        <Route exact path="/exercises" component={Exercises}/>
                                        <Route exact path="/form" component={Form}/>
                                        <Route exact path="/Calc" component={Calc}/>
                                        <Route component={Other}/>
                                    </Switch>
                                </Router>
                            </div>
                        </div>

                    </div>
                    <div className="wrapper">
                        <Footer />
                    </div>
                </div>

            </div>
        );

    };
}



export default App;


