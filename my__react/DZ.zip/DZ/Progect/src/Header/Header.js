import React from 'react';
import './Header.css';



class Header extends React.Component{
    constructor(props){
        super(props);
        this.state = {

        };
    };
    render(){

        return (
            <header className="header">
                <div className="container">
                    <div className="header_name">
                        <h2>Виталий</h2>
                        <h3>Front-end разработчик</h3>
                    </div>
                    <nav>
                        <ul>
                            {Object.keys(this.props.nav).map( key => {
                                if(key !== '404'){
                                    return <li key={key}><a href={this.props.nav[key].link}>{this.props.nav[key].title}</a></li>
                                }else{
                                    return "";
                                }
                            })}
                        </ul>
                    </nav>
                </div>
            </header>
        )
    }
}

export default Header;