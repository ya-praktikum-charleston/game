import React from 'react';
import './Main.css';

class Main extends React.Component{
    constructor(props){
        super(props);
        this.state = {

        };
    };
    render(){
        return (

            <div className="container">
                <ul className="box">
                    <li><a href={this.props.nav.exercises.link}>{this.props.nav.exercises.title}</a></li>
                    <li><a href={this.props.nav.form.link}>{this.props.nav.form.title}</a></li>
                    <li><a href={this.props.nav.calc.link}>{this.props.nav.calc.title}</a></li>
                </ul>
            </div>

        )
    }
}

export default Main;