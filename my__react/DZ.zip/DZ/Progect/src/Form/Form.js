import React from 'react';

import './Form.css';


class Form extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            text: "",
            number: "",
            range: 50,
            textarea: "",
            select: "1",
            completedTable: false,
            activeButton: false
        };

        this.myInput = this.myInput.bind(this);         //Пример использования .bind вместо стрелочной функции

    };
    myInput(e) {
        this.setState( {
            [e.target.name]: e.target.value
            //this.setState() является асинхронным. Если хочешь, чтобы что-то произошло после установки нового состояния, тебе необходимо включить его в качестве функции обратного вызова:
        },() => {
            let arrState = this.state;

            for(let key in arrState){
                if(arrState[key] === ''){
                    this.setState({ completedTable: false, activeButton: false });
                    return;
                }else{
                    this.setState({ completedTable: true });
                }
            }
        });


    };


    submitForm = (e) => {
        e.preventDefault();
        this.setState({ activeButton: true });
    };
    render(){

        let table = '';
        if (this.state.activeButton) {

            table =
                <div className="contain">
                    <table>
                        <tbody>
                        <tr>
                            <th>Текст</th>
                            <td>{this.state.text}</td>
                        </tr>
                        <tr>
                            <th>Число</th>
                            <td>{this.state.number}</td>
                        </tr>
                        <tr>
                            <th>Диапазон</th>
                            <td>{this.state.range}</td>
                        </tr>
                        <tr>
                            <th>Textarea</th>
                            <td>{this.state.textarea}</td>
                        </tr>
                        <tr>
                            <th>Select</th>
                            <td>{this.state.select}</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            ;
        }else{
            table = '';
        }
        return (
            <div className="App">

                <form onSubmit={this.submitForm}>

                    <input type="text" name="text" onChange={this.myInput} />
                    <br/>
                    <input type="number" name="number" onInput={this.myInput} />
                    <br/>
                    <input type="range" name="range" min="0" max="100" step="1" defaultValue={ this.state.range } onInput={this.myInput} />
                    <br/>
                    <textarea name="textarea" id="" cols="30" rows="10" onInput={this.myInput}></textarea>
                    <br/>
                    <select name="select" onInput={this.myInput}>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                    </select>
                    <br/>
                    <button type="submit" disabled={!this.state.completedTable}>Кнопка</button>


                    {table}


                </form>

            </div>
        );

    };
}



export default Form;


