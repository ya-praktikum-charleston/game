import React from 'react';

import './Exercises.css';


class Exercises extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            text: "Hello",
            count : 0,
            inpVal: "Введи текст",
            radioVal: "1",
            selectVal: "1",
            divWidth: '',
            rangeVal: '50',
            imgToogle: true
        };
        this.showText = this.showText.bind(this);
    };
    showText() {
        this.setState({ text: 'button work' });
        console.log('button work');
    };
    Count = () => {
        this.setState({ count: this.state.count + 1 });

    };
    ResetCount = () => {
        this.setState({ count: 0 });

    };
    move(){
        console.log('move');
    };
    Art(e) {
        console.log(e.target.getAttribute('data'));
    };
    inpText = (e) => {
        let val = e.target.value;
        if( val.length < 6 ){
            val = 'Теск меньше 6 символов';
        }
        this.setState({ inpVal: val });
    };
    checkboxFunk = (e) => {
        if( e.target.checked ){
            console.log('checkbox checked');
        }else{
            console.log('checkbox unchecked');
        }
    };
    radioFunk = (e) => {
        this.setState({ radioVal: e.target.value });
    };
    sectionFunk = (e) => {
        this.setState({ selectVal: e.target.value });
    };
    divFunk = () => {
        let div = document.querySelector('.task12');
        div.style.width = div.offsetWidth + 3 + 'px';
    };
    divResetFunk = () =>{
        let div = document.querySelector('.task12');
        div.style.width = 200 + 'px';
    };
    rangeFunk = (e) => {
        this.setState({ rangeVal: e.target.value });
    };
    imgToogle = () => {
        let div = document.querySelector('.img_toogle');
        if(this.state.imgToogle){
            this.setState({ imgToogle: false });
            div.style.display = "none";
        }else{
            this.setState({ imgToogle: true });
            div.style.display = "block";
        }
    };

    generatColor = () => {
        let min = 0;
        let max = 255;

        let a = Math.floor(Math.random() * (max - min + 1)) + min;
        let b = Math.floor(Math.random() * (max - min + 1)) + min;
        let c = Math.floor(Math.random() * (max - min + 1)) + min;

        return `rgb(${a},${b},${c})`;
    };

    generateNum = () => {
        let a = '';
        for(let i = 0; i <= 100; i++){
            a += i +' ';
        }
        return a;
    };
    render(){

        let arr = [1,2,3,4,5];
        let arr2 = [1,0,1,0];

        return (
            <div className="App">

                <p><i>===  Task 1 - 2</i></p>
                <p>Создайте кнопку. Повесьте на нее событие click. При клике выводите в консоль сообщение - button work. <br />
                    Добавьте параграф. При клике по кнопке - выводите текст button work в параграф.</p>
                <p>{this.state.text}</p>
                <button onClick={this.showText}>кнопка</button>


                <p><i>===  Task 3</i></p>
                <p>Добавьте кнопку с текстом Count. Создайте state.count = 0 и выведите его на страницу в параграф. Добавьте на кнопку Count событие, которое будет вызывать метод увеличивающий state.count на единицу при каждом нажатии.</p>
                <button onClick={this.Count}>Count</button>
                <p>{this.state.count}</p>


                <p><i>===  Task 4</i></p>
                <p>Добавьте кнопку ResetCount обновляющую count в предыдущей задаче.</p>
                <button onClick={this.ResetCount}>ResetCount</button>


                <p><i>===  Task 5</i></p>
                <div className="task5" onMouseMove={this.move}></div>
                <p>Добавьте div зеленого цвета. Повесьте на него событие mousemove и при срабатывании выводите в консоль слово move.</p>


                <p><i>===  Task 6</i></p>
                <p>Добавьте 2 кнопки с надписями atr1 и atr2. Задайте им атрибуты data = atr-1 и data = atr-2 соответственно. Добавьте по клику на кнопке метод (один и тот же). Метод должен выводить содержимое атрибута data в консоль.</p>
                <button data="atr1" onClick={this.Art}>atr1</button>
                <button data="atr2" onClick={this.Art}>atr2</button>


                <p><i>===  Task 7 - 8</i></p>
                <p>Добавьте input и параграф. При вводе текста в input - выводите в параграфе вводимый текст. <br />
                    Усложним задачу. Если длина вводимого текста меньше 6 символов - то выводите на страницу предупреждение о том, что длина меньше 6.</p>
                <input type="text" defaultValue={this.state.inpVal} onInput={ this.inpText } />
                <p>{this.state.inpVal}</p>

                <br/>

                <p><i>===  Task 9</i></p>
                <p>Добавьте checkbox - при изменении его состояния выводите checkbox checked или checkbox unchecked в консоль.</p>
                <input type="checkbox" onInput={ this.checkboxFunk } defaultChecked={true} />


                <p><i>===  Task 10</i></p>
                <p>Добавьте 3 radiobutton с одним именем. При изменении состояния radiobutton выводите value выбранного на страницу.</p>
                <input type="radio" name="radio" onInput={ this.radioFunk } defaultValue={'1'} defaultChecked={true} />
                <input type="radio" name="radio" onInput={ this.radioFunk } defaultValue={'2'} />
                <input type="radio" name="radio" onInput={ this.radioFunk } defaultValue={'3'} />
                <p>{this.state.radioVal}</p>

                <br/>

                <p><i>===  Task 11</i></p>
                <p>Добавьте выпадающий список. При изменении состояния - выводите value выбранного на страницу.</p>
                <select onChange={ this.sectionFunk }>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                </select>
                <p>{this.state.selectVal}</p>


                <p><i>===  Task 12</i></p>
                <p>Добавьте div и кнопку. При нажатии кнопки - увеличивайте ширину div на 3 px. Добавьте кнопку Reset позволяющую сбрасывать состояние до начальной ширины.</p>
                <div className="task12"></div>
                <br/>
                <button onClick={ this.divFunk }>Добавить ширину div</button>
                <button onClick={ this.divResetFunk }>Сбросить ширину div</button>


                <p><i>===  Task 13</i></p>
                <p>Добавьте полнузок. При изменении ползунка выводите его value на страницу.</p>
                <input type="range" min="0" max="100" step="1" defaultValue={this.state.rangeVal} onChange={ this.rangeFunk } />
                <p>{this.state.rangeVal}</p>

                <br/>

                <p><i>===  Task 14</i></p>
                <p>Добавьте кнопку и изображение. При клике на кнопку скрывайте изображение, при повторном клике - показывайте.</p>
                <button onClick={ this.imgToogle }>Кнопка</button>
                <br/>
                <img src="https://avatars.mds.yandex.net/get-pdb/202366/fb7cf1f2-6ce1-41d4-aa4a-8ce79bf2baf8/s1200" alt="" className="img_toogle"/>
                <br/>

                <p>Task 15</p>
                <p><i>Используя Expression выведите на страницу случайное число в диапазоне от 50 до 60 включительно. Число должно обновляться при загрузке страницы.</i></p>

                <p>{Math.floor(Math.random() * (60 - 50 + 1)) + 50}</p>

                <br/>

                <p>Task 16</p>
                <p><i>Создайте блок, через inline стили присвойте ему цвет фона. Причем цвет должен случайно меняться при загрузке страницы.</i></p>

                <div className="ts2" style={{backgroundColor:this.generatColor()}}></div>

                <br/>

                <p>Task 17</p>
                <p><i>Выведите с помощью Expression на страницу массив вида [1,2,3,4,5], каждый элемент списка должен быть выведен в отдельный параграф. Проверьте, необходимо ли добавлять ключ к параграфу? Если да - добавьте.</i></p>

                {arr.map( elem => {
                    return <p key={elem}>{elem}</p>
                })}

                <br/>

                <p>Task 18</p>
                <p><i>У вас есть массив [1,0,1,0]. Используя expression выведите на страницу данный массив, причем каждый элемент должен быть помещен в div. Если элемент равен 1, то div должен иметь класс white, если 0 - black.</i></p>

                {Object.keys(arr2).map( key => {
                    return <div key={key} className={(arr2[key] === 1) ? 'white' : 'black'}>{arr2[key]}</div>
                })}

                <br/>

                <p>Task 19</p>
                <p><i>Распечатайте цифры от 1 до 100 на странице с помощью expression.</i></p>

                <p>{this.generateNum()}</p>

            </div>
        );

    };
}



export default Exercises;


