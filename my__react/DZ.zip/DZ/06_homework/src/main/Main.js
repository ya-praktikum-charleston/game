import React from 'react';
import './Main.css';

class Main extends React.Component{
    render(){
        return (
            <div className="container">
                <ul className="box">
                    <li>РЕЗЮМЕ</li>
                    <li>ПРОЕКТЫ</li>
                    <li>НАВЫКИ</li>
                </ul>
            </div>
        )
    }
}

export default Main;