import React from 'react';
import './Footer.css';

class Footer extends React.Component{
    render(){
        return (
            <footer>
                <div className="container">
                    <p>Контакты</p>
                </div>
            </footer>
        )
    }
}

export default Footer;