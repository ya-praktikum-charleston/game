import React from 'react';
import './Header.css';

class Header extends React.Component{
    render(){
        return (
            <header className="header">
                <div className="container">
                    <div className="header_name">
                        <h2>Виталий</h2>
                        <h3>Front-end разработчик</h3>
                    </div>
                    <nav>
                        <ul>
                            <li><a href="#">ГЛАВНАЯ</a></li>
                            <li><a href="#">РЕЗЮМЕ</a></li>
                            <li><a href="#">ПРОЕКТЫ</a></li>
                            <li><a href="#">КОНТАКТЫ</a></li>
                        </ul>
                    </nav>
                </div>
            </header>
        )
    }
}

export default Header;