import React from 'react';

import './App.css';
import Header from '../header/Header.js';
import Main from '../main/Main.js';
import Footer from '../footer/Footer.js';
import Nav from '../Nav.js';

class App extends React.Component{
    render(){
        let contacts = this.props.contacts;
        let adress = this.props.adress;
        let titleFooter = this.props.titleFooter;
        let nav = this.props.nav;
        return (
            <div className="App">
                <div className="main_wrapper">
                    <div className="wrapper">
                        <Nav nav={nav}/>
                        <Header />
                        <Main />
                    </div>
                    <div className="wrapper">
                        <Footer contacts={contacts} adress={adress} titleFooter={titleFooter} />
                    </div>
                </div>
            </div>
        );
    }
}

export default App;
