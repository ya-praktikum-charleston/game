import React from 'react';



class Nav extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            title: "Navigation",
            subtitle: "Main menu",
            show: "show"
        }
    }
    showNav = () => {
        this.setState({ show: 'hide' });
        console.log('button work');
    }
    render(){
        let nav = this.props.nav;
        return (
            <div className="App">
                <button onClick={this.showNav}>Show Menu</button>
                <h1>{this.state.title}</h1>
                <nav>
                    {Object.keys(nav).map( elem => {
                        return <li><a href={nav[elem]}>{elem}</a></li>
                    })}
                </nav>
            </div>
        );
    }
}

export default Nav;
