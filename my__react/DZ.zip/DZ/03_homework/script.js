
// Task 1
let mac = new Mac('182', '79', '23', 'бывает', 'Жора', '3953 409385', 'зеленый');
console.log(mac);



// Task 2
let car = new Car('Жигули', '2101', '955', 'аи-76', 'Небесный', 'https://a.d-cd.net/5ac9824s-960.jpg');
console.log(car);



// Task 4

let img = 'https://cdn4.iconfinder.com/data/icons/logos-3/600/React.js_logo-256.png';
let mas = ['Контакт 1','Контакт 2','Контакт 3','Контакт 4'];

let header = new Header('Hello', 'world', 'девиз', img, mas );
header.render('header');



// Task 5

let car2 = new Car('Жигули', '2101', '955', 'АИ-92', 'Небесный', 'https://a.d-cd.net/5ac9824s-960.jpg');
car2.render('.pricing-table');

let car3 = new Car('Москвич', '412', '1045', 'АИ-93', 'Чёрный', 'https://pbs.twimg.com/media/Cxjmh6nWIAAB2DT.jpg:large');
car3.render('.pricing-table');

