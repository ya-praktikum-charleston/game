class Header {
    constructor( h1, h2, txt, img, contacts ) {
        this.h1 = h1;
        this.h2 = h2;
        this.txt = txt;
        this.src = img;
        this.contacts = contacts;
    }

    render(div) {

        let html = '';

        html += `<h1>${this.h1}</h1>`;
        html += `<h2>${this.h2}</h2>`;
        html += `<p>${this.txt}</p>`;
        html += `<img src="${this.src}" alt="">`;
        html += `<ul>`;

        this.contacts.forEach(function (elem) {
            html += `<li>${elem}</li>`;
        });

        html += `</ul>`;


        document.querySelector(div).innerHTML = html;

    }

}