class Car {
    constructor( brand, name, weight, fuel_type, color, img ) {
        this.brand = brand;
        this.name = name;
        this.weight = weight;
        this.fuel_type = fuel_type;
        this.color = color;
        this.img = img;
    }

    render(div) {

        let html = '';

        html += `<div class="col col-md-6 col-lg-2">`;
        html += `<div class="package">`;
        html += `<p class="package-name">${this.brand} - ${this.name}</p>`;
        html += `<hr>`;
        html += `<img src="${this.img}" alt="">`;
        html += `<hr>`;
        html += `<ul class="features">`;
        html += `<li>Вес : ${this.weight}</li>`;
        html += `<li>Топливо : ${this.fuel_type}</li>`;
        html += `<li>Цвет : ${this.color}</li>`;
        html += `</ul>`;
        html += `</div>`;
        html += `</div>`;

        document.querySelector(div).innerHTML += html;

    }

}