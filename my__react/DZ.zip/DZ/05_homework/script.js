
// Task 1

let car = {
    model: 'T',
    weight: '1050',
    color: 'Желтый',
    go: function(){
        console.log('go и model');
        return true;
    }
}



// Task 2
console.log('========= Task 2 =========');

let ford = {
    year: '1981'
}

console.log(ford);



// Task 3
console.log('========= Task 3 =========');

ford.__proto__ = car;

console.log(ford);



// Task 4
console.log('========= Task 4 =========');

console.log(ford.model);
console.log(ford.weight);
console.log(ford.color);
ford.go();



// Task 5
console.log('========= Task 5 =========');

car.mileage = '382 789';

console.log(ford.mileage);



// Task 6
console.log('========= Task 6 =========');

ford.go = function () {
    console.log('Год: ' + ford.year + ' - Цвет: ' + ford.color);
    return true;
}

ford.go();



// Task 7
console.log('========= Task 7 =========');

ford.__proto__.go();



// Task 8
console.log('========= Task 8 =========');

let chevrolet = {};

Object.setPrototypeOf(chevrolet,ford);

console.log(chevrolet.model);
console.log(chevrolet.color);
console.log(chevrolet.mileage);
console.log(chevrolet.go());



// Task 9
console.log('========= Task 9 =========');

chevrolet.go = function () {
    console.log('Задайте свой метод go для chevrolet');
    return true;
}

console.log(chevrolet.go());



// Task 10
console.log('========= Task 10 =========');

chevrolet.body_style = 'body_style';
chevrolet.drive_type = 'drive_type';

console.log(chevrolet.body_style);
console.log(chevrolet.drive_type);



// Task 11
console.log('========= Task 11 =========');

for(let key in chevrolet){
    console.log(chevrolet[key]);
}




































//