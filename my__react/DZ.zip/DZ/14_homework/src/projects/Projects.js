import React from 'react';

import './projects.css';

class About extends React.Component{
    constructor(props){
        super(props);
        this.state = {

        };

    };

    render(){

        return (
            <div className="App">

                <h1>Проекты</h1>

            </div>
        );

    };
}



export default About;


