import React from 'react';
import './main.css';

class Main extends React.Component{
    constructor(props){
        super(props);
        this.state = {

        };
    };
    render(){
        return (

            <div className="container">
                <ul className="box">
                    <li><a href={this.props.nav.summary.link}>{this.props.nav.summary.title}</a></li>
                    <li><a href={this.props.nav.projects.link}>{this.props.nav.projects.title}</a></li>
                    <li><a href={this.props.nav.contacts.link}>{this.props.nav.contacts.title}</a></li>
                </ul>
            </div>

        )
    }
}

export default Main;