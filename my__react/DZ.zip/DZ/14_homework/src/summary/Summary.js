import React from 'react';

import './summary.css';

class Summary extends React.Component{
    constructor(props){
        super(props);
        this.state = {

        };

    };

    render(){

        return (
            <div className="main">

                <h1>Резюме</h1>

            </div>
        );

    };
}



export default Summary;


