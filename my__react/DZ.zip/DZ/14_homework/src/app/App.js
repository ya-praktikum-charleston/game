import React from 'react';

import './app.css';

import { BrowserRouter as Router, Switch, Route} from 'react-router-dom';

import Header from '../header/Header.js';
import Main from '../main/Main.js';
import Footer from '../footer/Footer.js';

import Summary from '../summary/Summary.js';
import Projects from '../projects/Projects.js';
import Contacts from '../contacts/Contacts.js';
import Other from '../other/Other';


class App extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            nav: {
                main: {
                    component: 'Main', title: 'ГЛАВНАЯ', link: '/'
                },
                summary: {
                    component: 'Summary', title: 'РЕЗЮМЕ', link: '/summary'
                },
                projects: {
                    component: 'Projects', title: 'ПРОЕКТЫ', link: '/projects'
                },
                contacts: {
                    component: 'Contacts', title: 'КОНТАКТЫ', link: '/contacts'
                },
                '404': {
                    component: 'Other', title: '404', link: ''
                },
            }
        };

    };

    render(){

        return (
            <div className="App">

                <div className="main_wrapper">
                    <div className="wrapper">
                        <Header nav={this.state.nav}/>
                        <div className="main">
                            <div className="container">
                                <Router>
                                    <Switch>
                                        <Route exact path="/" component={() => <Main nav={this.state.nav}/>}/>
                                        <Route exact path="/summary" component={Summary}/>
                                        <Route exact path="/projects" component={Projects}/>
                                        <Route exact path="/contacts" component={Contacts}/>
                                        <Route component={Other}/>
                                    </Switch>
                                </Router>
                            </div>
                        </div>

                    </div>
                    <div className="wrapper">
                        <Footer />
                    </div>
                </div>

            </div>
        );

    };
}



export default App;


