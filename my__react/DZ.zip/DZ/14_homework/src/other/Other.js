import React from 'react';

import './other.css';


class Other extends React.Component{
    constructor(props){
        super(props);
        this.state = {

        };

    };

    render(){

        return (
            <div className="App">

                <h1>страница 404</h1>

            </div>
        );

    };
}



export default Other;


