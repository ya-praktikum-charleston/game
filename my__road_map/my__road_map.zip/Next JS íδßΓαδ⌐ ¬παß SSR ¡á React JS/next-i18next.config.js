module.exports = {
    i18n: {
        defaultLocale: 'ru',
        locales: ['ru', 'en'],
    },
}
