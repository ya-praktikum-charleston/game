export default function Error() {
    return (
        <h1>
            МОЯ КАСТОМНАЯ СТРАНИЦА С ОШИБКОЙ
        </h1>
    )
};
