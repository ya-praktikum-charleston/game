import MainContainer from "../components/MainContainer";

const Index = () => {
    return (
        <MainContainer keywords={"main page"} title={'Главная страница'}>

            <h1>Главная страница</h1>

        </MainContainer>
    );
};

export default Index;


