import { combineReducers } from "redux";

import units from "./units";

export default combineReducers({
    units
});
