# nextReact

- npm init -y
- npm next react react-dom
- npm install axios
- npm install --save redux
- npm install --save redux-thunk
- npm install next-redux-wrapper react-redux --save
- npm install --save redux-devtools-extension


## Запуск
npm run dev
