#Redux Toolkit.

## Урок

1. Redux Toolkit. Сделай redux код проще!
https://www.youtube.com/watch?v=cFWpwtkto1s

2. Redux Toolkit. CreateSlice. Сделай redux код проще!
https://www.youtube.com/watch?v=gNu-Zsn-k7w